import pandas as pd
from sqlalchemy import create_engine

from config import DB_HOST, DB_LOGIN, DB_NAME, DB_PASSWORD

# Подключение к БД

engine = create_engine(f"postgresql://{DB_LOGIN}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}")

# Extract
sql_query = """
    SELECT
        "Order ID",
        "Order Date",
        "Customer Name",
        category,
        "Sub-Category",
        "Product Name",
        sales,
        profit
    FROM
        superstore"""

src_table = pd.read_sql(sql_query, engine)

# Transform
furniture_table = src_table[src_table['category'] == 'Furniture']

# группировка по одной мере
aggr_table = furniture_table \
    .groupby(['category','Sub-Category']) \
    .agg(value = pd.NamedAgg(column='sales', aggfunc='sum')) \
    .reset_index()

# группировка по нескольким колонкам
aggr_table2 = furniture_table \
    .groupby(['category','Sub-Category']) \
    .agg(
        count = pd.NamedAgg(column='sales', aggfunc='count'),
        sum_sales = pd.NamedAgg(column='sales', aggfunc='sum'),
        sum_profit = pd.NamedAgg(column='profit', aggfunc='sum')).reset_index()

# Load
aggr_table2.to_excel('pandas_data.xlsx','Отчет',index=False)