from typing import OrderedDict
import psycopg2
import petl as etl

from config import DB_HOST, DB_LOGIN, DB_NAME, DB_PASSWORD

# подключение к БД
connection = psycopg2.connect(host=DB_HOST, database=DB_NAME, user=DB_LOGIN, password=DB_PASSWORD)

# Extract
sql_query = """
    SELECT
        "Order ID",
        "Order Date",
        "Customer Name",
        category,
        "Sub-Category",
        "Product Name",
        sales,
        profit
    FROM
        superstore"""

src_table = etl.fromdb(connection, sql_query)

# Transform
furniture_table = etl.selecteq(src_table,'category','Furniture')

# группировка по одной мере
aggr_table = etl.aggregate(furniture_table, 
                            key=('category','Sub-Category'), 
                            aggregation=sum,
                            value='sales')

# print(aggr_table)
# группировка по нескольким колонкам. Для этого нужен упорядоченный словарь OrderedDict

aggregations = OrderedDict()
aggregations['count'] = len
aggregations['sum_sales'] = 'sales', sum
aggregations['sum_profit'] = 'profit', sum

aggr_table2 = etl.aggregate(furniture_table, 
                            key=('category','Sub-Category'), 
                            aggregation=aggregations)


# Load
etl.toxlsx(aggr_table2, 'petl_data.xlsx', 'Отчет')